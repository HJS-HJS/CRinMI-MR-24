# crinmi_mr > 2024-08-17 7:22am
https://universe.roboflow.com/crinmimr/crinmi_mr

Provided by a Roboflow user
License: BY-NC-SA 4.0

